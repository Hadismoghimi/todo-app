import shutil

shutil.make_archive("output", "zip", "../Day1")