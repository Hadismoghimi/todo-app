# def count(phrase):
#     return phrase.count('.')


# def count(phrase):
#     return phrase.count('.')

def count(phrase):
    return phrase.count('.')