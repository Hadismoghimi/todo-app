# import functions
#
# nr_of_periods = functions.count("Trees are good. Grass is green.")
# print(nr_of_periods)

# import functions
#
# nr_of_periods = functions.count("Trees are good. Grass is green.")
# print(nr_of_periods)


from functions import count

nr_of_periods =  count("Trees are good. Grass is green.")
print(nr_of_periods)

