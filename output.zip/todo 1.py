# user_prompt = "enter a todo"
# to_do1 = input(user_prompt)
# todo2 = input(user_prompt)
# todo3 = input(user_prompt)
#
# todos = [to_do1, todo2, todo3]
# print(todos)
#
# text = input("enter a text: ")
# allowed_range = 10
# length = len(text)
# if length > allowed_range:
#     print(" yor desciption is too long!!!")
#
#   text = input("enter a text: ")
#     length = len(text)
#     if length > allowed_range:
#         print(" yor desciption is too long!!!")
# else:
     print(" your desciption is too long!!!")

#defined_password = "@Ww$1540"
# user_password= input("Enter your password: ") # if defined_password == user_password:
#. print("Your logged in, Welcome back!") # else:
# print("wrong password!")
# user_password= input("Enter your password: ") #if defined_password == user_password:
# print("Your logged in, Welcome back!")
#else:
#
# print("wrong password!")
# متغيرها Variables
# رشته String
# عدد صحيح Integer
# عدد اعشاري Float
# آرایه با متغیر چند بعدي List
# Boolean 0 1
name "hello"
# Counter = 1-
# mark 17.75
# marks = [15, 11, 3, 20]
# flag = True
# print(type (name))
# print(type (counter))
# print(type (mark))
# print(type (marks))
# print(type (flag))